<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<style>
body {font-family: Arial, Helvetica, sans-serif;}


input {
  width: 300px;
  padding: 12px 14px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  box-sizing: border-box;
}

button {
  background-color: #1ebae6;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 300px;
  font-weight: bold;
}

input[type=submit] {
  background-color: #1ebae6;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 300px;
  font-weight: bold;
}

h2 {
  padding: 0px 15px;
}

input[type=submit]:hover {
  opacity: 0.8;
}

button:hover {
  opacity: 0.8;
}

.container {
  padding: 16px;
}


</style>
</head>
<body>

<h2>All Messages</h2>

<div class="container"> 
    <form method="post">
    <?php

	$files = glob("*.txt");
	$num = 0;
	foreach($files as $file) {
    	$data = fopen($file, "r") or die("Unable to open file!");
                  echo "<input type='text'  name= 'inputfield" . $num . "' id='field" . $num . "' value=" . fgets($data) . " readonly><input name='delete' title='Delete Message' id='" . $num . "' type='submit' value='" . $num . "'><br>" ;
                  fclose($data);
	$num++;                                                                                                                    
	}

	if(isset($_POST['delete']))
                  {
                  	$buttname =  $_POST['delete'];
		unlink($files[$buttname]);
		header("Location: all_messages_adm.php");
		/*
		$name = "inputfield" . $buttname
		$value = $_POST[$name];
		foreach($files as $file) {
			$data2 = 	 fopen($file, "r") or die("Unable to open file!");
			$check = 	fgets($data2);
			if($check == $value)
				{
				fclose($data2);
				unlink($file);
				}
			else
				{
				fclose($data2);
				}
                 		 }
		*/
	}

                  //nl2br(fread($data, filesize($file))
    ?><br>
    <input type="submit" name="add" value="Post New Message"><br>
    <input type="submit" name="leave" value="Log Out">
    <?php
    if(isset($_POST['leave'])) {
    header("Location: all_messages.php");
    }
    if(isset($_POST['add'])) {
    header("Location: new_message.php");
    }
    ?>
    </form>
</div>

</body>
</html>