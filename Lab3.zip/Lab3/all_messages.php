<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<style>
body {font-family: Arial, Helvetica, sans-serif;}


input {
  width: 300px;
  padding: 12px 14px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  box-sizing: border-box;
}

button {
  background-color: #1ebae6;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 300px;
  font-weight: bold;
}

input[type=submit] {
  background-color: #1ebae6;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 300px;
  font-weight: bold;
}

h2 {
  padding: 0px 15px;
}

input[type=submit]:hover {
  opacity: 0.8;
}

.container {
  padding: 16px;
}


</style>
</head>
<body>

<h2>All Messages</h2>

<div class="container"> 
    <?php
	$files = glob("*.txt");
	$num = 0;
	foreach($files as $file) {
    	$data = fopen($file, "r") or die("Unable to open file!");
                  echo "<input type='text'  name= 'inputfield" . $num . "' id='field" . $num . "' value=" . fgets($data) . " readonly><br>" ;
                  fclose($data);
	$num++;                                                                                                                    
	}
    ?><br>
    <form action="/login.php">
    <input type="submit" value="Admin Panel">
    </form>
</div>

</body>
</html>