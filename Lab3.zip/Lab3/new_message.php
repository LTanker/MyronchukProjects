<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {font-family: Arial, Helvetica, sans-serif;}

input {
  width: 300px;
  padding: 12px 14px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  box-sizing: border-box;
}

textarea {
  width: 300px;
  padding: 12px 14px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  box-sizing: border-box;
  resize: none;
}

input[type=submit] {
  background-color: #1ebae6;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 300px;
  font-weight: bold;
}

input[type=submit]:hover {
  opacity: 0.8;
}

h2 {
  padding: 0px 15px;
}

button:hover {
  opacity: 0.8;
}

.container {
  padding: 16px;
}


</style>
</head>
<body>

<h2>New Message</h2>

<form method="post" >

  <div class="container">    
    <input type="text" name="newmessage" id="newmessage" rows="8" placeholder="Write here your message"></textarea><br>       
    <input type="submit" name="submit" value="Submit">
  </div>

</form>

<?php


if(isset($_POST["newmessage"]))
{
$data=$_POST["newmessage"];
$fp = fopen("themessage" . time() . ".txt", "a");
fwrite($fp, $data);
fclose($fp);
header('Location: all_messages_adm.php');
}
exit;
?>

</body>
</html>



