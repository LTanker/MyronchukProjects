<!DOCTYPE html>
<html>
<style>
table#table1 {
    width:100%; 
}
input[type=submit] {
  font-weight: bold;
  width: 20%;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
}

input {
  width: 20%;
  padding: 8px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  box-sizing: border-box;
}

div {
  margin-left:41.5%; 
}
input[type=submit]:hover {
  opacity: 0.8;
}
</style>
<body>

<?php
echo "<table class='center' id='table1' style='border: solid 1px black;'>";
 echo "<tr><th>Id</th><th>Firstname</th><th>Lastname</th><th>Salary</th><th>Department</th><th>E-mail</th></tr>";

class TableRows extends RecursiveIteratorIterator {
    function __construct($it) {
        parent::__construct($it, self::LEAVES_ONLY);
    }

    function current() {
        return "<td style='width: 150px; border: 1px solid black;'>" . parent::current(). "</td>";
    }

    function beginChildren() {
        echo "<tr>";
    }

    function endChildren() {
        echo "</tr>" . "\n";
    }
}

$servername = "localhost";
$username = "user1";
$dbname = "myDBemp";

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $stmt = $conn->prepare("SELECT id, firstname, lastname, salary, departmentname, email FROM emp");
    $stmt->execute();

    // set the resulting array to associative
    $result = $stmt->setFetchMode(PDO::FETCH_ASSOC);

    foreach(new TableRows(new RecursiveArrayIterator($stmt->fetchAll())) as $k=>$v) {
        echo $v;
    }
}
catch(PDOException $e) {
    echo "Error: " . $e->getMessage();
}
$conn = null;
echo "</table>";

    if(isset($_POST['del'])) {
    try {
      $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username);
      $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
      $id = $_POST['id'];
      $delete = "DELETE FROM emp WHERE id=$id";
      $conn->exec($delete);
      header("Location: /dbex/delete.php");
    } catch(PDOException $e) {
      $conn->rollback();
      echo $delete . "<br>" . $e->getMessage();
}

$conn = null;
      }
    if(isset($_POST['back'])) {
      header("Location: /dbex/display.php");
      }
?>
<div>
<form method="post">
<input type="text" placeholder="ID of deleted record" name="id"><br>
<input type="submit" style=" background-color: #fc6f03;"  name="del" value="Delete Record"><br>
<input type="submit" style=" background-color: #e3073e;"  name="back" value="Back To Display"><br>
</form>
</div>
</body>
</html>