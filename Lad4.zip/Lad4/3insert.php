<?php
$servername = "localhost";
$username = "user1";
$dbname = "myDBemp";

try {
  $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username);
  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

  $conn->beginTransaction();
  $conn->exec("INSERT INTO emp (id, firstname, lastname, salary, departmentname, email)
  VALUES (1, 'Vladyslav', 'Myronchuk', 2000.00, 'Seller', 'myronchuk_vladyslav@ukr.net')");
  $conn->exec("INSERT INTO emp (id, firstname, lastname, salary, departmentname, email)
  VALUES (2, 'Alex', 'Cosov', 3000.00, 'Administrator', 'acosov@meta.ua')");
  $conn->exec("INSERT INTO emp (id, firstname, lastname, salary, departmentname, email)
  VALUES (3, 'Hlib', 'Kovtunenko', 2800.00, 'CoAdministrator', 'kovthl@meta.ua')");
  $conn->commit();
  echo "New records created successfully";
} catch(PDOException $e) {
  $conn->rollback();
  echo "Error: " . $e->getMessage();
}

$conn = null;
?>