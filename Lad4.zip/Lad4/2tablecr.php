<?php
$servername = "localhost";
$username = "user1";
$dbname = "myDBemp";

try {
  $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username);
  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

  $table = "CREATE TABLE emp (
  id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  firstname VARCHAR(30) NOT NULL,
  lastname VARCHAR(30) NOT NULL,
  salary DECIMAL(10,2) NOT NULL,
  departmentname VARCHAR(30) NOT NULL,
  email VARCHAR(30) NOT NULL)";
  $conn->exec($table);
  echo "Table created successfully<br>";
} catch(PDOException $e) {
  echo $table . "<br>" . $e->getMessage();
}

$conn = null;
?>