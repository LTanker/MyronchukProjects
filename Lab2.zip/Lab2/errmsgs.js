    $("input").change(function(){
    if(document.getElementById("male").checked) {
 	document.getElementById("children").disabled = true;
    }
    else{
    document.getElementById("children").disabled = false;
    }
    });
    
//First name errors
    $("input").change(function(){
	var inp = $("#fname").val();
    if(inp == "") {
 	$("#errfirstname").text("  First name must be filled out!");
    }
    else if(!inp.replace(/\s/g, '').length) {
    $("#errfirstname").text("  First name filled with whitespaces only!");
    }
    else{
    $("#errfirstname").text("  ");
    }
    });
    
    //Last name errors
    $("input").change(function(){
	var inp = $("#lname").val();
    if (inp == "") {
 	$("#errlastname").text("  Last name must be filled out!");
    }
    else if (!inp.replace(/\s/g, '').length) {
    $("#errlastname").text("  Last name filled with whitespaces only!");
    }
    else{
    $("#errlastname").text("  ");
    }});
    
    //Number of children errors
    $("input").change(function(){
	var inp = $("#children").val();
    if (!inp.match(/^[0-9]*$/)) {
 	$("#errchildren").text("  Number of children must be nonnegative or empty!");
    }
    else{
    $("#errchildren").text("  ");
    }});
    
    //Email errors
    $("input").change(function(){
	var inp = $("#email").val();
    if (inp == "") {
 	$("#erremail").text("  E-mail must be filled out!");
    }
    else if (!inp.replace(/\s/g, '').length) {
    $("#erremail").text("  E-mail filled with whitespaces only!");
    }
    else if (!inp.match(/[@]/) || !inp.match(/[.]/)) {
    $("#erremail").text("  E-mail must contain @ or .!");
    }
    else{
    $("#erremail").text("  ");
    }});
    
    //Zip errors
    $("input").keyup(function(){
	var inp = $("#zip").val();
    if (inp == "") {
 	$("#errzip").text("  Zip code must be filled out!");
    }
    else if (!inp.replace(/\s/g, '').length) {
    $("#errzip").text("  Zip code filled with whitespaces only!");
    }
    else if (inp.length != 5 || !inp.match(/^[0-9]*$/)) {
    $("#errzip").text("  Zip code must contain 5 digits!");
    }
    else{
    $("#errzip").text("  ");
    }});