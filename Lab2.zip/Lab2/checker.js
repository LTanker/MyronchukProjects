function validateForm() {     
  var allcheck = new Boolean(true);
  var firstnamecheck = document.forms["myForm"]["fname"].value;
  var lastnamecheck = document.forms["myForm"]["lname"].value;
  var childrencheck = document.forms["myForm"]["children"].value;
  var emailcheck = document.forms["myForm"]["email"].value;
  var zipcheck = document.forms["myForm"]["zip"].value;
  
  if (firstnamecheck == false) {
    allcheck = false;
  }
  else if (!firstnamecheck.replace(/\s/g, '').length) {
    //document.getElementById("errfirstname").innerHTML = "  First name filled with whitespaces only!";
    allcheck = false;
  }
  else {
    document.getElementById("errfirstname").innerHTML = "  ";
  }
  if (lastnamecheck == "") {
    //document.getElementById("errlastname").innerHTML = "  Last name must be filled out!";
    allcheck = false;
  }
  else if (!lastnamecheck.replace(/\s/g, '').length) {
    //document.getElementById("errlastname").innerHTML = "  Last name filled with whitespaces only!";
    allcheck = false;
  }
  else {
    //document.getElementById("errlastname").innerHTML = "  ";
  }
  if (!childrencheck.match(/^[0-9]*$/)) {
    //document.getElementById("errchildren").innerHTML = "  Number of children must be nonnegative or empty!";
    allcheck = false;
  }
  else {
    //document.getElementById("errchildren").innerHTML = "  ";
  }
  if (emailcheck == "") {
    //document.getElementById("erremail").innerHTML = "  E-mail must be filled out!";
    allcheck = false;
  }
  else if (!emailcheck.replace(/\s/g, '').length) {
    //document.getElementById("erremail").innerHTML = "  E-mail filled with whitespaces only!";
    allcheck = false;
  }
  else if (!emailcheck.match(/[@]/) || !emailcheck.match(/[.]/)) {
    //document.getElementById("erremail").innerHTML = "  E-mail must contain @ or .!";
    allcheck = false;
  }
  else {
    //document.getElementById("erremail").innerHTML = "  ";
  }
  if (zipcheck == "") {
    //document.getElementById("errzip").innerHTML = "  Zip code must be filled out!";
    allcheck = false;
  }
  else if (!zipcheck.replace(/\s/g, '').length && zipcheck != "") {
    //document.getElementById("errzip").innerHTML = "  Zip code filled with whitespaces only!";
    allcheck = false;
  }
  else if (zipcheck.length != 5 || !childrencheck.match(/^[0-9]*$/)) {
    //document.getElementById("errzip").innerHTML = "  Zip code must contain 5 numbers!";
    allcheck = false;
  }
  else {
    //document.getElementById("errzip").innerHTML = "  ";
  }
  if (allcheck == false) {
  return false
  }
}