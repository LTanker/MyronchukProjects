<?php
$servername = "localhost";
$username = "user1";
$dbname = "myDBproject";

try {
  $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username);
  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

  $table = "CREATE TABLE user (
  id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(30) NOT NULL,
  password VARCHAR(30) NOT NULL)";
  $conn->exec($table);
  echo "Table created successfully<br>";
  $table = "CREATE TABLE admin (
  id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(30) NOT NULL,
  password VARCHAR(30) NOT NULL)";
  $conn->exec($table);
  echo "Table created successfully<br>";
  $table = "CREATE TABLE games (
  id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(30) NOT NULL,
  genre VARCHAR(30) NOT NULL,
  price DECIMAL(10,2) NOT NULL,
  developer VARCHAR(30) NOT NULL,
  publisher VARCHAR(30) NOT NULL)";
  $conn->exec($table);
  echo "Table created successfully<br>";
} catch(PDOException $e) {
  echo $table . "<br>" . $e->getMessage();
}

$conn = null;
?>