<?php
$servername = "localhost";
$username = "user1";
$dbname = "myDBproject";

try {
  $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username);
  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

  $conn->beginTransaction();
  $conn->exec("INSERT INTO user (id, username, password)
  VALUES (1, 'igrolub', 'qwerty123')");
  $conn->exec("INSERT INTO user (id, username, password)
  VALUES (2, 'gamelover', 'password')");
  $conn->exec("INSERT INTO user (id, username, password)
  VALUES (3, 'userplayer', 'notaplayer')");
  $conn->commit();
  echo "New records created successfully";

  $conn->beginTransaction();
  $conn->exec("INSERT INTO admin (id, username, password)
  VALUES (1, 'LTankerAdmin', 'vladik005')");
  $conn->commit();
  echo "New records created successfully";

  $conn->beginTransaction();
  $conn->exec("INSERT INTO games (id, name, genre, price, developer, publisher)
  VALUES (1, 'The Witcher 3', 'Action RPG', 60.00, 'CD Project RED', '1C')");
  $conn->exec("INSERT INTO games (id, name, genre, price, developer, publisher)
  VALUES (2, 'Detroit: Become Human', 'Action-adventure', 50.00, 'Quantic Dream', 'Sony Entertainment')");
  $conn->exec("INSERT INTO games (id, name, genre, price, developer, publisher)
  VALUES (3, 'Terraria', 'Action-adventure', 15.00, 'Re-Logic', 'Re-Logic')");
  $conn->exec("INSERT INTO games (id, name, genre, price, developer, publisher)
  VALUES (4, 'Superliminal', 'Game-puzzle', 10.00, 'Pillow Castle', 'Pillow Castle')");
  $conn->exec("INSERT INTO games (id, name, genre, price, developer, publisher)
  VALUES (5, 'Grand Theft Auto IV', 'Action-adventure', 60.00, 'Rockstar North', 'Rockstar Games')");
  $conn->exec("INSERT INTO games (id, name, genre, price, developer, publisher)
  VALUES (6, 'Borderlands 3', 'Role-playing', 40.00, 'Gearbox Software', '2K')");
  $conn->commit();
  echo "New records created successfully";

} catch(PDOException $e) {
  $conn->rollback();
  echo "Error: " . $e->getMessage();
}

$conn = null;
?>