<!DOCTYPE html>
<?php
$servername = "localhost";
$username = "user1";
$dbname = "myDBproject";
if(isset($_POST['logout'])) {
  header("Location: /myproject/indexunlogin.php");
}
if(isset($_POST['del'])) {
    try {
      $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username);
      $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
      $id = $_POST['id'];
      $delete = "DELETE FROM games WHERE id=$id";
      $conn->exec($delete);
      header("Location: /myproject/delete.php");
      exit;
    } catch(PDOException $e) {
      $conn->rollback();
      echo "Error: " . $e->getMessage();
}
}
?>
<html>
<head>
<style>
.recordclass input[type=submit] {
  font-weight: bold;
  width: 20%;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
}

table {
border-collapse : collapse;
width: 100%;
color: black;
font-family: monospace;
font-size: 32px;
text-align: left;
}

th {
background-color: #d96459;
color: white;
}

td {
background-color: #ffe4de;
}

* {box-sizing: border-box;}

body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.topnav {
  overflow: hidden;
  background-color: black;
}

.topnav a {
  float: left;
  display: block;
  color: black;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
  background-color: #2196F3;
  color: white;
}

.topnav .login-container {
  float: right;
}

input[type=text] {
  padding: 6px;
  margin-top: 8px;
  font-size: 17px;
  border: none;
  width:120px;
}

.topnav .login-container input[type=submit] {
  padding: 15px;
  float: right;
  background-color: #630310;
  color: white;
  font-weight: bold;
  font-size: 26px;
  border: none;
  cursor: pointer;
}

.topnav .login-container input[type=submit]:hover {
  background-color: #940418;
}

@media screen and (max-width: 600px) {
  .topnav .login-container {
    float: none;
  }
  .topnav a, .topnav input[type=text], .topnav .login-container button {
    float: none;
    display: block;
    text-align: left;
    width: 100%;
    margin: 0;
    padding: 14px;
  }
  .topnav input[type=text] {
    border: 1px solid #ccc;  
  }
}
.left {
  padding: 15px;
  float: right;
  background-color: #630310;
  color: white;
  font-weight: bold;
  font-size: 26px;
  border: none;
  cursor: pointer;
}
.left:hover {
  background-color: #940418;
}
</style>
</head>
<body>
<div class="topnav">
  
    <form method="post">
      <input type="submit" style="float: left; background-color: #d10622;" name="back" id="back" class="left" value="Go Back">
      <div class="login-container">
      <input type="submit" name="logout" id="logout" value="Log Out">
    </form>
      </div>
</div>
<?php
if(isset($_POST['back'])) {
  header("Location: /myproject/indexadmin.php");
  exit;
}
echo "<table style='border: solid 1px black;'>";
 echo "<tr><th style='width: 3%; '>ID</th><th>GameName</th><th>Genre</th><th style='width: 7%; '>Price</th><th>Developer</th><th style='width: 20%; '>Publisher</th></tr>";

class TableRows extends RecursiveIteratorIterator {
    function __construct($it) {
        parent::__construct($it, self::LEAVES_ONLY);
    }

    function current() {
        return "<td style='width: 150px; border: 1px solid black;'>" . parent::current(). "</td>";
    }

    function beginChildren() {
        echo "<tr>";
    }

    function endChildren() {
        echo "</tr>" . "\n";
    }
}

$servername = "localhost";
$username = "user1";
$dbname = "myDBproject";

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $stmt = $conn->prepare("SELECT id, name, genre, price, developer, publisher FROM games");
    $stmt->execute();

    // set the resulting array to associative
    $result = $stmt->setFetchMode(PDO::FETCH_ASSOC);

    foreach(new TableRows(new RecursiveArrayIterator($stmt->fetchAll())) as $k=>$v) {
        echo $v;
    }
}
catch(PDOException $e) {
    echo "Error: " . $e->getMessage();
}
$conn = null;
echo "</table>";
?>
<div>
<form method="post">
<input type="text" style="width: 20%; padding: 8px 20px; margin: 8px 0; display: inline-block; border: 1px solid #ccc; box-sizing: border-box;" placeholder="id of deleted record" name="id" id="id"><br>
<input type="submit" style=" background-color: #fc6f03; font-weight: bold; width: 20%; color: white; padding: 14px 20px; margin: 8px 0; border: none; cursor: pointer;" class="recordclass" name="del" value="Delete Record"><br>
</form>
</div>
</body>
</html>