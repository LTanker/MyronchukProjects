<!DOCTYPE html>

<?php
$servername = "localhost";
$username = "user1";
$dbname = "myDBproject";
if(isset($_POST['register'])) {
  try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $nickname = $_POST['username'];
    $password = $_POST['password'];
    $conn->beginTransaction();
    $conn->exec("INSERT INTO user (username, password)
    VALUES('$nickname', '$password')");
    $conn->commit();
    header("Location: /myproject/login.php");
  }catch(PDOException $e) {
    echo "Error: " . $e->getMessage();
  }
$conn = null;
}
if(isset($_POST['back'])) {
  header('Location: /myproject/indexunlogin.php');
  exit;
}
?>

<html>
<head>
<style>
.err{ 
     color: red;
     font-weight: bold;
    }
</style>
<meta name="viewport" content="width=device-width, initial-scale=1">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.0/jquery.min.js"></script>
<style>
body {font-family: Arial, Helvetica, sans-serif;}


input {
  width: 300px;
  padding: 12px 14px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  box-sizing: border-box;
}

button {
  background-color: #1ebae6;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 300px;
  font-weight: bold;
}

h2 {
  padding: 0px 15px;
}

button:hover {
  opacity: 0.8;
}

.container {
  padding: 16px;
}

input[type=submit] {
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 300px;
  font-weight: bold;
}

#register {
display : none;
}

input[type=submit]:hover {
  opacity: 0.8;
}


</style>
</head>
<body>

<h2>Sign Up</h2>

<form method="post">

  <div class="container">
    <label for="name"><b>Username</b></label><br>
    <input type="text" placeholder="Enter Username" name="username" id="username"><span id="errusername" class="err"></span><br>

    <label for="psw"><b>Password</b></label><br>
    <input type="password" placeholder="Enter Password" name="password" id="password"><span id="errpassword" class="err"></span><br>
        
    <input type="submit" style=" background-color: #1ebae6;" name="register" id="register" value="Register"><br>
    <input type="submit" style=" background-color: #e3073e;" name="back" id="back" value="Back To Main Page"><br>
  </div>
</form>
<script>
$(document).ready(function() {
    var usercheck = new Boolean(false);
    var pswcheck = new Boolean(false);
    //Username errors
    if ($("#username").val() == "") {
 	$("#errusername").text("  Username must be filled out!");
	usercheck = false;
    document.getElementById("register").style.display = "none";
    }
    $("input").keyup(function(){
	var inp = $("#username").val();
    if (inp == "") {
 	$("#errusername").text("  Username must be filled out!");
	usercheck = false;
    document.getElementById("register").style.display = "none";
    }
    else if (inp.length < 7) {
    $("#errusername").text("  Username must be at least 6 characters long!");
    usercheck = false;
    document.getElementById("register").style.display = "none";
    }
    else if (inp.match(/[ `!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?~]/)) {
    $("#errusername").text("  Username must not contain special characters!");
    usercheck = false;
    document.getElementById("register").style.display = "none";
    }
    else{
    $("#errusername").text("");
    usercheck = true;
    document.getElementById("register").style.display = "block";
    if(pswcheck)
    {
    document.getElementById("register").style.display = "block";
    }
    else
    {
    document.getElementById("register").style.display = "none";
    }
    }});

    //Password errors
    if ($("#password").val() == "") {
 	$("#errpassword").text("  Password must be filled out!");
	pswcheck = false;
    document.getElementById("register").style.display = "none";
    }
    $("input").keyup(function(){
	var inp = $("#password").val();
    if (inp == "") {
 	$("#errpassword").text("  Password must be filled out!");
	pswcheck = false;
    document.getElementById("register").style.display = "none";
    }
    else if (inp.length < 9) {
    $("#errpassword").text("  Password must be at least 8 characters long!");
    pswcheck = false;
    document.getElementById("register").style.display = "none";
    }
    else if (inp.match(/[ `!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?~]/)) {
    $("#errpassword").text("  Password must not contain special characters!");
    pswcheck = false;
    document.getElementById("register").style.display = "none";
    }
    else{
    $("#errpassword").text("");
    pswcheck = true;
    document.getElementById("register").style.display = "block";
    
    if(usercheck)
    {
    document.getElementById("register").style.display = "block";
    }
    else
    {
    document.getElementById("register").style.display = "none";
    }
    }});
});
</script>
</body>
</html>