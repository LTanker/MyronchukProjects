<!DOCTYPE html>
<html>
<head>
<style>

table {
border-collapse : collapse;
width: 100%;
color: black;
font-family: monospace;
font-size: 32px;
text-align: left;
}

th {
background-color: #d96459;
color: white;
}

td {
background-color: #ffe4de;
}

* {box-sizing: border-box;}

body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.topnav {
  overflow: hidden;
  background-color: black;
}

.topnav a {
  float: left;
  display: block;
  color: black;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
  background-color: #2196F3;
  color: white;
}

.topnav .login-container {
  float: right;
}

.topnav input[type=text] {
  padding: 6px;
  margin-top: 8px;
  font-size: 17px;
  border: none;
  width:120px;
}

.topnav .login-container input[type=submit] {
  padding: 15px;
  float: right;
  background-color: #630310;
  color: white;
  font-weight: bold;
  font-size: 26px;
  border: none;
  cursor: pointer;
}

.topnav .login-container input[type=submit]:hover {
  background-color: #940418;
}

@media screen and (max-width: 600px) {
  .topnav .login-container {
    float: none;
  }
  .topnav a, .topnav input[type=text], .topnav .login-container button {
    float: none;
    display: block;
    text-align: left;
    width: 100%;
    margin: 0;
    padding: 14px;
  }
  .topnav input[type=text] {
    border: 1px solid #ccc;  
  }
}
</style>
</head>
<body>
<div class="topnav">
  <div class="login-container">
    <form method="post">
      <input type="submit" name="logout" id="logout" value="Log Out"></button>
    </form>
  </div>
</div>
<?php
if(isset($_POST['logout'])) {
  header("Location: /myproject/indexunlogin.php");
}
echo "<table style='border: solid 1px black;'>";
 echo "<tr><th style='width: 3%; '>ID</th><th>GameName</th><th>Genre</th><th style='width: 7%; '>Price</th><th>Developer</th><th style='width: 20%; '>Publisher</th></tr>";

class TableRows extends RecursiveIteratorIterator {
    function __construct($it) {
        parent::__construct($it, self::LEAVES_ONLY);
    }

    function current() {
        return "<td style='width: 150px; border: 1px solid black;'>" . parent::current(). "</td>";
    }

    function beginChildren() {
        echo "<tr>";
    }

    function endChildren() {
        echo "</tr>" . "\n";
    }
}

$servername = "localhost";
$username = "user1";
$dbname = "myDBproject";

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $stmt = $conn->prepare("SELECT id, name, genre, price, developer, publisher FROM games");
    $stmt->execute();

    // set the resulting array to associative
    $result = $stmt->setFetchMode(PDO::FETCH_ASSOC);

    foreach(new TableRows(new RecursiveArrayIterator($stmt->fetchAll())) as $k=>$v) {
        echo $v;
    }
}
catch(PDOException $e) {
    echo "Error: " . $e->getMessage();
}
$conn = null;
echo "</table>";
?>

</body>
</html>