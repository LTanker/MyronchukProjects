<?php
$servername = "localhost";
$username = "user1";

try {
  $conn = new PDO("mysql:host=$servername", $username);
  // set the PDO error mode to exception
  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  $database = "CREATE DATABASE myDBProject";
  $conn->exec($database);
  echo "Database created successfully<br>";
} catch(PDOException $e) {
  echo $database . "<br>" . $e->getMessage();
}

$conn = null;
?>