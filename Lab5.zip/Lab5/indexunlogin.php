<!DOCTYPE html>
<html>
<head>
<style>

table {
border-collapse : collapse;
width: 100%;
color: black;
font-family: monospace;
font-size: 32px;
text-align: left;
}

th {
background-color: #d96459;
color: white;
}

td {
background-color: #ffe4de;
}

* {box-sizing: border-box;}

body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.topnav {
  overflow: hidden;
  background-color: black;
}

.topnav a {
  float: left;
  display: block;
  color: black;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
  background-color: #2196F3;
  color: white;
}

.topnav .login-container {
  float: right;
}

.topnav input[type=text] {
  padding: 6px;
  margin-top: 8px;
  font-size: 17px;
  border: none;
  width:120px;
}

.topnav .login-container input[type=submit] {
  padding: 15px;
  float: right;
  background-color: #630310;
  color: white;
  font-weight: bold;
  font-size: 26px;
  border: none;
  cursor: pointer;
}

.topnav .login-container input[type=submit]:hover {
  background-color: #940418;
}

@media screen and (max-width: 600px) {
  .topnav .login-container {
    float: none;
  }
  .topnav a, .topnav input[type=text], .topnav .login-container button {
    float: none;
    display: block;
    text-align: left;
    width: 100%;
    margin: 0;
    padding: 14px;
  }
  .topnav input[type=text] {
    border: 1px solid #ccc;  
  }
}
</style>
</head>
<body>
<div class="topnav">
  <div class="login-container">
    <form method="post">
      <input type="submit" style=" background-color: #02d467;" name="reg" id="reg" value="Register">
      <input type="submit" style=" background-color: #077ed9;" name="log" id="log" value="Login">
    </form>
  </div>
</div>
<h1 style="text-align: center; color: red;">Please Login into your account to see the table
<?php
if(isset($_POST['log'])) {
  header("Location: /myproject/login.php");
}
if(isset($_POST['reg'])) {
  header("Location: /myproject/signup.php");
}
?>

</body>
</html>